function NotFound() { return <div className='container py-5'><h2>404 - Halaman tidak ditemukan</h2></div> } export default NotFound
