function Gallery() { return <div className='container py-5'><h2>Galeri</h2></div> } export default Gallery
