import React, { useEffect } from 'react'
import AOS from 'aos'
import 'aos/dist/aos.css'

function Home() {
  useEffect(() => {
    AOS.init({ once: true });
  }, [])

  return (
    <div className="home-premium">
      <section
        className="hero d-flex align-items-center justify-content-center text-center text-white"
        style={{
          height: '100vh',
          background: 'linear-gradient(120deg, #0a2647, #144272)',
          color: '#fff',
          paddingTop: '80px'
        }}
      >
        <div data-aos="fade-up">
          <h1 style={{ fontSize: '4rem', fontWeight: '700' }}>CBJ Kontruksi</h1>
          <p className="lead mt-3" style={{ fontSize: '1.5rem' }}>
            Kami bangun masa depan Anda dengan kualitas dan kepercayaan
          </p>
          <a href="/contact" className="btn btn-outline-light btn-lg mt-4">Hubungi Kami</a>
        </div>
      </section>

      <section className="intro py-5 bg-white text-center">
        <div className="container" data-aos="fade-up">
          <h2 className="fw-bold mb-4">Mengapa Memilih CBJ?</h2>
          <p className="text-muted">
            Lebih dari 10 tahun membangun proyek dengan presisi tinggi, tenaga ahli profesional, dan kepuasan klien maksimal.
          </p>
        </div>
      </section>

      <section className="features py-5 bg-light">
        <div className="container">
          <div className="row text-center">
            <div className="col-md-4" data-aos="fade-up">
              <h4 className="fw-bold">Teknologi Modern</h4>
              <p className="text-muted">Menggunakan perangkat dan teknik terkini dalam setiap pembangunan.</p>
            </div>
            <div className="col-md-4" data-aos="fade-up" data-aos-delay="150">
              <h4 className="fw-bold">Tim Profesional</h4>
              <p className="text-muted">Engineer berpengalaman dan bersertifikat siap mengerjakan proyek Anda.</p>
            </div>
            <div className="col-md-4" data-aos="fade-up" data-aos-delay="300">
              <h4 className="fw-bold">Proyek Tepat Waktu</h4>
              <p className="text-muted">Manajemen proyek efektif dengan timeline yang realistis dan akurat.</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default Home
