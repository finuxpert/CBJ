function Contact() { return <div className='container py-5'><h2>Kontak Kami</h2></div> } export default Contact
